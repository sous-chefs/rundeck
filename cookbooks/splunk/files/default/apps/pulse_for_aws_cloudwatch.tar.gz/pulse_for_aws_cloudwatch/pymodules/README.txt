Extract the following modules to this directory and execute the commands:

- Python Boto -- http://code.google.com/p/boto/
- Python Dateutil 1.5-- http://labix.org/python-dateutil

-  ln -s $SPLUNK_HOME/etc/apps/pulse_for_aws_cloudwatch/pymodules/boto-2.1.1/boto $SPLUNK_HOME/etc/apps/pulse_for_aws_cloudwatch/bin
-  ln –s $SPLUNK_HOME/etc/apps/pulse_for_aws_cloudwatch/pymodules/python-dateutil-1.5/dateutil $SPLUNK_HOME/etc/apps/pulse_for_aws_cloudwatch/bin
